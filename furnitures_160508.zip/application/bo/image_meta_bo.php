<?php
/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class Image_MetaBO extends BO {
    public $aperture;
	public $credit;
	public $camera;
	public $caption;
	public $created_timestamp;
	public $copyright;
	public $focal_length;
	public $iso;
	public $shutter_speed;
	public $title;
	public $orientation;
	public $keywords;   
    function __construct()
    {
        
    }

}