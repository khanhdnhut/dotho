<?php

/*
 * Language for: views/admin/index.php
 */
define("TITLE_DASHBOARD", "Dashboard");
define("TITLE_HOME", "Home");
define("TITLE_COLLAPSE_MENU", "Collapse menu");
define("TITLE_VIEW_SITE", "Visit Site");
define("TITLE_NEW", "New");
define("TITLE_EDIT_MY_PROFILE", "Edit My Profile");
define("TITLE_LOGOUT", "Log Out");
define("TITLE_FOOTER_THANKYOU", "Thank you for creating with ");
define("TITLE_VERSION", "Version 1.0");

