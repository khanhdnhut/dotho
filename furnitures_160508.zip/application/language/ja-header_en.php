<?php

/*
 * Language for: views/_templates/ja-header.php
 */
define("JA_HEADER_LOGO_TITLE", "Vietnam Travel");
define("JA_HEADER_CUSTOMER_SERVICE_HOTLINE_TITLE", "Customer Service Hotline: ");
define("JA_HEADER_CUSTOMER_SERVICE_HOTLINE", "(+84) 91-608-3030");
define("JA_HEADER_EMAIL_SALES_TITLE", "/ Email: ");
define("JA_HEADER_EMAIL_SALES", "sales@svietnamtravel.com");
define("JA_HEADER_PHONE_OFFICE_TITLE", "Office: ");
define("JA_HEADER_PHONE_OFFICE", "(+84) 436-830-236");
define("JA_HEADER_PHONE_OFFICE_DESCRIPTION", " (Mon-Fri: 8h - 17h30 GMT+7)");
define("JA_HEADER_CUSTOMIZED_TOUR_TITLE", "ENQUIRE");
define("JA_HEADER_CUSTOMIZED_TOUR_HREF", "/customized-tour.html");
