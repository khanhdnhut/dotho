<?php

define("ADMIN_CP", "admin/");