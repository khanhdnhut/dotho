<?php

define("CATEGORY_CP_INDEX", "category/index/");
define("CATEGORY_CP_BY_PARENT_AJAX", "category/getByParent/");
define("CATEGORY_CP_ADD_NEW", "category/addNew/");
define("CATEGORY_CP_EDIT", "category/editInfo/");
define("CATEGORY_CP_VIEW", "category/view/");
define("CATEGORY_CP_INFO", "category/info/");