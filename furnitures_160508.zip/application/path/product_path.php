<?php

define("PRODUCT_CP_INDEX", "product/index/");
define("PRODUCT_CP_BY_CATEGORY_AJAX", "product/getByCategory/");
define("PRODUCT_CP_ADD_NEW", "product/addNew/");
define("PRODUCT_CP_EDIT", "product/editInfo/");
define("PRODUCT_CP_VIEW", "product/view/");
define("PRODUCT_CP_INFO", "product/info/");