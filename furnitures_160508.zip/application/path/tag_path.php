<?php

define("TAG_CP_INDEX", "tag/index/");
define("TAG_CP_ADD_NEW", "tag/addNew/");
define("TAG_CP_SEARCH_AJAX", "tag/searchAjax/");
define("TAG_CP_EDIT", "tag/editInfo/");
define("TAG_CP_INFO", "tag/info/");