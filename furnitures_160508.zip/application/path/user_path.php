<?php

define("USER_CP_INDEX", "user/index/");
define("USER_CP_EDIT", "user/editInfo/");
define("USER_CP_INFO", "user/info/");
define("USER_CP_DELETE", "user/delete/");
define("USER_CP_LOST_PASSWORD", "user/lostpassword/");
define("USER_CP_ADD_NEW", "user/addNew/");
define("USER_CP_PROFILE", "user/profile/");
define("USER_CP_LOGIN", "user/login/");
define("USER_CP_LOGOUT", "user/logout/");
define("USER_CP_FILTER_ADMIN", "user/filter/administrator/");
define("USER_CP_FILTER_EDITOR", "user/filter/editor/");
define("USER_CP_FILTER_AUTHOR", "user/filter/author/");
define("USER_CP_FILTER_CONTRIBUTOR", "user/filter/contributor/");
define("USER_CP_FILTER_SUBSCRIBER", "user/filter/subscriber/");
