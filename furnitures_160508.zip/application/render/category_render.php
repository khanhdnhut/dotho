<?php

define("CATEGORY_RV_INDEX", "category/category_index");
define("CATEGORY_RV_SEARCH_BY_PARENT_AJAX", "category/category_by_parent");
define("CATEGORY_RV_NAVBAR", "category/category_navbar");
define("CATEGORY_RV_SIDEBAR", "category/category_sidebar");
define("CATEGORY_RV_ALL_CATEGORY", "category/category_home");
define("CATEGORY_RV_ADD_NEW", "category/category_add_new");
define("CATEGORY_RV_EDIT", "category/category_edit");
define("CATEGORY_RV_INFO", "category/category_info");
define("CATEGORY_RV_VIEW", "category/category_view");
define("CATEGORY_RV_VIEW_AJAX", "category/category_view_ajax");