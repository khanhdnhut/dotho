<?php

define("ERROR_RV_INDEX", "error/error_index");
define("ERROR_RV_NOTFOUND", "error/notFound");