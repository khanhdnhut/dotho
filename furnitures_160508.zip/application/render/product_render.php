<?php

define("PRODUCT_RV_INDEX", "product/product_index");
define("PRODUCT_RV_SEARCH_BY_CATEGORY_AJAX", "product/product_by_category");
define("PRODUCT_RV_ADD_NEW", "product/product_add_new");
define("PRODUCT_RV_EDIT", "product/product_edit");
define("PRODUCT_RV_INFO", "product/product_info");
define("PRODUCT_RV_VIEW", "product/product_view");