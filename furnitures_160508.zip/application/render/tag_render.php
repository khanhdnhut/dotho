<?php

define("TAG_RV_INDEX", "tag/tag_index");
define("TAG_RV_SEARCH_AJAX", "tag/tag_search_ajax");
define("TAG_RV_ADD_NEW", "tag/tag_add_new");
define("TAG_RV_EDIT", "tag/tag_edit");
define("TAG_RV_INFO", "tag/tag_info");