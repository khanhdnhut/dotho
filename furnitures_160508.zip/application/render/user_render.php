<?php

define("USER_RV_INDEX", "user/user_index");
define("USER_RV_ADD_NEW", "user/user_add_new");
define("USER_RV_EDIT", "user/user_edit");
define("USER_RV_INFO", "user/user_info");
define("USER_RV_LOGIN", "user/login");
