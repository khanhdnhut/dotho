</div>
<div class="clear"></div>
</div>
<div class="clear"></div>
</div>
<div class="clear"></div>
<!-- wpbody -->
<div class="clear"></div>
</div>
<div role="contentinfo" id="wpfooter">
    <p class="alignleft" id="footer-left">
        <span id="footer-thankyou"><?php echo TITLE_FOOTER_THANKYOU; ?><a href="<?php echo URL; ?>"><?php echo WEBSITE_NAME; ?></a>.</span> </p>
    <p class="alignright" id="footer-upgrade"><?php echo TITLE_VERSION; ?></p>
    <div class="clear"></div>
</div>

<div class="hidden" id="wp-auth-check-wrap">
    <div id="wp-auth-check-bg"></div>
    <div id="wp-auth-check">
        <div title="Close" tabindex="0" class="wp-auth-check-close"></div>
        <div data-src="<?php echo URL . USER_CP_LOGIN; ?>" id="wp-auth-check-form"></div>
    </div>
</div>

<!--<script src="<?php echo PUBLIC_JS; ?>includes/hoverIntent.js?ver=4.4" type="text/javascript"></script>
--><script src="<?php echo PUBLIC_JS; ?>admin/common.js?ver=4.4" type="text/javascript"></script>
<script src="<?php echo PUBLIC_JS; ?>includes/admin-bar.js?ver=4.4" type="text/javascript"></script>
<!--<script src="<?php echo PUBLIC_JS; ?>includes/wp-ajax-response.js?ver=4.4" type="text/javascript"></script>-->
<script src="<?php echo PUBLIC_JS; ?>includes/jquery/jquery.color.min.js?ver=4.4" type="text/javascript"></script>
<!--<script src="<?php echo PUBLIC_JS; ?>includes/wp-lists.js?ver=4.4" type="text/javascript"></script>
<script src="<?php echo PUBLIC_JS; ?>includes/quicktags.js?ver=4.4" type="text/javascript"></script>-->
<script src="<?php echo PUBLIC_JS; ?>includes/jquery/jquery.query.js?ver=4.4" type="text/javascript"></script>
<!--<script src="<?php echo PUBLIC_JS; ?>admin/comment.js?ver=4.4" type="text/javascript"></script>-->
<script src="<?php echo PUBLIC_JS; ?>includes/jquery/ui/core.min.js?ver=4.4" type="text/javascript"></script>
<script src="<?php echo PUBLIC_JS; ?>includes/jquery/jquery.js?ver=4.4" type="text/javascript"></script>
<script src="<?php echo PUBLIC_JS; ?>includes/jquery/ui/widget.min.js?ver=4.4" type="text/javascript"></script>
<script src="<?php echo PUBLIC_JS; ?>includes/jquery/ui/mouse.min.js?ver=4.4" type="text/javascript"></script>
<script src="<?php echo PUBLIC_JS; ?>includes/jquery/ui/sortable.min.js?ver=4.4" type="text/javascript"></script>
<!--<script src="<?php echo PUBLIC_JS; ?>includes/jquery/ui/tooltip.min.js?ver=4.4" type="text/javascript"></script>-->
<!--<script src="<?php echo PUBLIC_JS; ?>admin/postbox.js?ver=4.4" type="text/javascript"></script>-->
<!--<script src="<?php echo PUBLIC_JS; ?>admin/dashboard.js?ver=4.4" type="text/javascript"></script>-->
<!--<script src="<?php echo PUBLIC_JS; ?>includes/underscore.js?ver=4.4" type="text/javascript"></script>
<script src="<?php echo PUBLIC_JS; ?>includes/customize-base.js?ver=4.4" type="text/javascript"></script>
<script src="<?php echo PUBLIC_JS; ?>includes/customize-loader.js?ver=4.4" type="text/javascript"></script>
<script src="<?php echo PUBLIC_JS; ?>includes/thickbox/thickbox.js?ver=4.4" type="text/javascript"></script>
<script src="<?php echo PUBLIC_JS; ?>admin/plugin-instal.js?ver=4.4" type="text/javascript"></script>
<script src="<?php echo PUBLIC_JS; ?>includes/shortcode.js?ver=4.4" type="text/javascript"></script>
<script src="<?php echo PUBLIC_JS; ?>admin/media-upload.js?ver=4.4" type="text/javascript"></script>
<script src="<?php echo PUBLIC_JS; ?>admin/svg-painter.js?ver=4.4" type="text/javascript"></script>
<script src="<?php echo PUBLIC_JS; ?>includes/heartbeat.js?ver=4.4" type="text/javascript"></script>
<script src="<?php echo PUBLIC_JS; ?>includes/wp-auth-check.js?ver=4.4" type="text/javascript"></script>
<script src="<?php echo PUBLIC_JS; ?>includes/wplink.js?ver=4.4" type="text/javascript"></script>-->

<script src="<?php echo PUBLIC_JS; ?>admin/ajax-link.js?ver=4.4" type="text/javascript"></script>

<div style="display: none; font-family: 'Open Sans',sans-serif; font-size: 14px; line-height: 19.6px; padding: 6px 7px; white-space: pre-wrap; word-wrap: break-word;" class="quick-draft-textarea-clone"></div>
<div id="customize-container"></div>
</body>

</html>