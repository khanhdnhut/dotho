
                    </div>
                </div>
            </div>
        </section>
        <footer>
            <?php require VIEW_TEMPLATES_PATH . 'home/footer.php'; ?>
            <?php require VIEW_TEMPLATES_PATH . 'home/copyright.php'; ?>
            
        </footer>
    </body>
</html>