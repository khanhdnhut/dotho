            <div class="banner-header">
                <a href="<?php echo URL; ?>">
                    <img src="<?php echo PUBLIC_IMG . "sondong/header-sondong-1.png"; ?>" style="width:100%;" alt="Đồ thờ Sơn Đồng - Hiệp Thủy">
                </a>
            </div>