<?php require VIEW_TEMPLATES_PATH . 'home/header.php'; ?>  
    <body>       
        <div class="container">
            <?php require VIEW_TEMPLATES_PATH . 'home/banner.php'; ?>                       
            <?php // require VIEW_TEMPLATES_PATH . 'home/navbar.php'; ?>
        </div>
        <section>
            <div class="container">
                <div class="row" style="background:white;margin:0px;">
                    <?php require VIEW_TEMPLATES_PATH . 'home/sidebar.php'; ?>
                    
                    <div class="col-sm-9half" style="padding-right:2px;padding-left:2px;">
                        
