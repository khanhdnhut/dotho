<div class="clearfix " id="zt-footer">
    <div class="container">
        <div class="row-fluid pattern0" id="zt-footer-inner">
            <div style=" text-align:center;" id="zt-footer-left">


                <div id="zt-footer-copy">


                    <div class="custom" style="color: rgb(248, 177, 80) ! important; margin: 1em 0px; font-size: 12px;">
                        <p>Copyright &copy; 2006 <?php echo DEFAULT_SITE_NAME; ?></p></div>

                </div>
            </div>

            <div class="clearfix"></div>
        </div>
    </div>
</div>