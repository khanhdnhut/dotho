
<?php
Controller::autoloadController("category");
$categoryCtrl = new CategoryCtrl();
$categoryCtrl->getProductAllCategory();

?>


